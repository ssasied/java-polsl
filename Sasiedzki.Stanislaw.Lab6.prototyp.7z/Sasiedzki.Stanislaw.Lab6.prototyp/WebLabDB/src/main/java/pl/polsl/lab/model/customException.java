// In package model
package pl.polsl.lab.model;

public class customException extends Exception {
    public customException(){
        super("error occured");
    }
    public customException(String message) {
        super(message);
    }
}
