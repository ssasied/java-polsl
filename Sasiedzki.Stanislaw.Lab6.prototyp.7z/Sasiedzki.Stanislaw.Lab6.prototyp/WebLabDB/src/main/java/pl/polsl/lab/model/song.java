package pl.polsl.lab.model;

import java.util.Vector;
import lombok.*;

/**
 *
 * @author SuperStudent-PL
 */
public class song {
    
    @Getter @Setter
    private String songTitle;
        
    @Getter @Setter
    private Vector<String> authors;
    
    @Getter @Setter
    private int numberInAlbum;

    // Constructor with song name and number in album
    public song(String songName, int numberInAlbum) throws customException {
        if (songName == null || songName.isEmpty()) {
            throw new customException("Song name cannot be null or empty.");
        }
        if (numberInAlbum <= 0) {
            throw new customException("Number in album must be greater than zero.");
        }
        this.songTitle = songName;
        this.numberInAlbum = numberInAlbum;
    }

    // Constructor with song title, authors, and number in album
    public song(String songTitle, Vector<String> authors, int numberInAlbum) throws customException {
        if (songTitle == null || songTitle.isEmpty()) {
            throw new customException("Song title cannot be null or empty.");
        }
        if (authors == null || authors.isEmpty()) {
            throw new customException("Authors list cannot be null or empty.");
        }
        if (numberInAlbum <= 0) {
            throw new customException("Number in album must be greater than zero.");
        }
        this.songTitle = songTitle;
        this.authors = authors;
        this.numberInAlbum = numberInAlbum;
    }
}
