/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.lab.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.Pattern;
import java.io.Serializable;
import lombok.*;

/**
 *
 * @author SuperStudent-PL
 */
@Entity
public class UserX implements Serializable{
    
    //@Getter @Setter
    @Column(name = "name")
    @Pattern(regexp = "^[A-Z][a-z]*$", flags = Pattern.Flag.UNICODE_CASE)
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public UserX() {
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }
    
    
    
    
    //@Getter @Setter
    @Column(name = "surname")
    @Pattern(regexp = "^[A-Z][a-z]*$", flags = Pattern.Flag.UNICODE_CASE)
    private String surname;
    
    //@Getter @Setter
    @Id
    @Column(name="id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    
    
    public UserX(String name,String surname){
        this.name = name;
        this.surname = surname;        
    }
    
    public UserX(String name, String surname, int id) throws customException {
    if(name==null||name.trim().isEmpty()) throw new customException("fill in name");
    if(surname==null||surname.trim().isEmpty()) throw new customException("fill in surname");
    this.name = name;
    this.surname = surname;
    this.id = id;
    
    
}


    
    
    
}
