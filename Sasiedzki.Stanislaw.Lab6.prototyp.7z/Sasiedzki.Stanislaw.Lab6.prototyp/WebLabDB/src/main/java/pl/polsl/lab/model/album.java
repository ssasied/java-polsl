/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.lab.model;

import java.time.LocalDateTime;
import java.util.Set;
import java.util.Vector;
import lombok.*;

/**
 *
 * @author ssasied
 * 
 */
public class album {
    
   @Getter @Setter
    private String albumTitle;
    
   @Getter @Setter
    private int id;
   
   @Getter @Setter
    private LocalDateTime productionDate;    
   
   //@Getter @Setter
    private Vector<song>songs = new Vector<song>();

    public Vector<song> getSongs() {
        return songs;
    }

    public void setSongs(Vector<song> songs) {
        this.songs = songs;
    }
   
    
    
   @Getter @Setter
    private int numberOfSongs = 0;

    
    
    public album(String title, int id) throws customException {
    if (title == null || title.trim().isEmpty()) {
        throw new customException("fill in title");
    }
    this.albumTitle = title;        
    this.id = id;
    this.numberOfSongs = 0;
}


    public album(String albumTitle, int id, LocalDateTime productionDate) throws customException {
        if(albumTitle.trim().isEmpty()) throw new customException("fill in title");
        this.albumTitle = albumTitle;
        this.id = id;
        this.productionDate = productionDate;
        this.numberOfSongs = 0;    
    }

    public album(String albumTitle, int id, Vector<song> songs)  throws customException {
        if(albumTitle.trim().isEmpty()) throw new customException("fill in title");
        this.albumTitle = albumTitle;
        this.id = id;
        this.songs = songs;
    }

    
    
    
}
