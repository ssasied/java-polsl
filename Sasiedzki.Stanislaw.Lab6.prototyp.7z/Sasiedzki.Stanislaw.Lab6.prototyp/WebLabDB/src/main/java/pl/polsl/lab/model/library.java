/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pl.polsl.lab.model;

import jakarta.persistence.Column;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import lombok.*;

/**
 *
 * @author ssasied
 * main library class
 */
public class library implements LibDataSource{
   
   @Getter @Setter
   private List<UserX> users;
   
   @Getter @Setter
   private Map<String,album> albums;
   
   @Getter @Setter
   private UserX currentUser;
   
   @Getter @Setter
   private int nextAlbumId;
  
   @Getter @Setter
   private int nextUserId;
   
    public library() throws customException{
        this.users = new Vector<UserX>();
        this.albums = new HashMap<String,album>();
        this.nextAlbumId=1;
        this.nextUserId=1;
        try{
        this.currentUser = new UserX("test","user",0); //login        
        }catch(Exception e){}
//read data and update albums vector and current ids
    }
    
    
    /**
     * adds album to albums vector
     * @param albumTitle string title of album
     * @param songs vector of songs in album
     * @return 
     */
    public void addAlbum(String albumTitle, Vector<song> songs)throws customException{
       if(albums.containsKey(albumTitle)){
            throw new customException("cant duplicate albums");
        }
            album newAlbum = new album(albumTitle,nextAlbumId++, songs);
            albums.put(albumTitle,newAlbum);
            
     }
        
    
    /**
     * overloaded addAlbum function with production date
     * @param albumTitle string title of album
     * @param productionDate LocalDateTime production date
     * @param songs vector of songs in album
     * @return 
     */
    public void addAlbum(String albumTitle, LocalDateTime productionDate,  Vector<song> songs) throws customException{
        
        if(albums.containsKey(albumTitle)){
            throw new customException("cant duplicate albums");
        }
        if (songs == null || songs.isEmpty()) {
        throw new customException("Empty song Vector");
    }
        
        album newAlbum = new album(albumTitle,nextAlbumId++,productionDate);            
        newAlbum.setSongs(songs);           
        albums.put(albumTitle,newAlbum);        
    }
    
    /**
     * adds user to users vector
     * @param name 
     * @param surname 
     * @return 
     */
   @Override
    public void addUser(String name, String surname) {
        try{
            users.add(new UserX(name, surname, nextUserId++));
        }
        catch(Exception e){}
            
        
    }
    /**
     * adds admin to user vector
     * @param name
     * @param surname
     * @return 
     */
   @Override
    public void addAdmin(String name, String surname){
        try{
            users.add(new admin(name, surname, nextUserId++));
        }
        catch(Exception e){
            
        }
        
    }
   @Override
    public Vector<UserX> getAdmins() {
        Vector<UserX>admins = new Vector();
        for(UserX us : users){
            if(us instanceof admin){
                admins.add(us);
            }
        }        
        return admins;
    }
    
    public Set<String> getAlbumNames(){
        return  albums.keySet();
    }
   public Collection<album> getAlbumValues(){
        return albums.values();
    }
   
   @Override
    public int getNextUserId(){
        return 0;
    }
    
    public List<UserX> getUsers(){
        return new ArrayList<UserX>();
    }
}
