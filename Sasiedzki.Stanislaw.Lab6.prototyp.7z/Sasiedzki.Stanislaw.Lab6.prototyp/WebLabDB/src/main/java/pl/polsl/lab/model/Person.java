package pl.polsl.lab.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import jakarta.validation.constraints.Pattern.Flag;
import java.io.Serializable;
import java.util.Date;
import lombok.*;

@Entity
@Getter @Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Person implements Serializable{

    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;   
    
    @Column(name = "firstname", length = 20)
    @Pattern(regexp = "^[A-Z][a-z]*$", flags = Flag.UNICODE_CASE)
    private String firstName;

    @Column(name = "lastname", length = 20)
    @Pattern(regexp = "^[A-Z][a-z]*$", flags = Flag.UNICODE_CASE)
    private String lastName;
    
    @Column(name = "email", length = 100)
    @NotBlank
    @Email
    private String email;
    
    @Column(name = "vip")
    private boolean vip;
    
    //@Column(name = "gender")
    //@Enumerated(EnumType.ORDINAL)
    //private Gender gender;
       
    @Column(name = "dateofbirth")
    @Temporal(TemporalType.DATE)
    private Date dateOfBirth;    
       
}