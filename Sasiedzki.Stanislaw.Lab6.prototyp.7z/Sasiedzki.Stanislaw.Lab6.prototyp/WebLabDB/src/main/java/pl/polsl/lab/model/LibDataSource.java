package pl.polsl.lab.model;

import java.util.List;
import java.util.Map;
import java.util.Vector;

public interface LibDataSource {    
    public List<UserX> getUsers();
    public Vector<UserX> getAdmins();
    public void addUser(String name, String surname);
    public void addAdmin(String name, String surname);
    public int getNextUserId();
}
