package pl.pols.lab.services;

import jakarta.servlet.http.HttpServlet;
import java.util.logging.Level;
import java.util.logging.Logger;
import pl.polsl.lab.model.DatabaseSource;
import pl.polsl.lab.model.LibDataSource;
import pl.polsl.lab.model.customException;
import pl.polsl.lab.model.library;

public class InitializationServlet extends HttpServlet { 
    
    @Override
    public void init() {
        
        var context = getServletContext();        
        LibDataSource dataSource = (LibDataSource)context.getAttribute("LibDataSource");
        if(dataSource == null) {
            context.setAttribute("LibDataSource", new DatabaseSource());
            
//            try {
//                context.setAttribute("LibDataSource", new library());
//                
//            } catch (customException ex) {
//                Logger.getLogger(InitializationServlet.class.getName()).log(Level.SEVERE, null, ex);
//                System.out.println("nowa biblia");
//            }
        }
        
    }   
    
}
