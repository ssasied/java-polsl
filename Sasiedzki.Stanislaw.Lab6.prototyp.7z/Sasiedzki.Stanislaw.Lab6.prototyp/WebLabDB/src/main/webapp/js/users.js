

function getUsersTable(tableId) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState === 4 && this.status === 200) {
      // Populate the table body with the response
      document.getElementById(tableId).innerHTML = this.responseText;
    }
  };

  xhttp.open("GET","displayUser",true); 
  xhttp.send();
}

function getAdminsTable(tableId) {
  var xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function() {
    if (this.readyState === 4 && this.status === 200) {
      document.getElementById(tableId).innerHTML = this.responseText;
    }
  };

  xhttp.open("GET","displayAdmin",true); 
  xhttp.send();
}


function addUser(name,surname) {
    var xhttp = new XMLHttpRequest();
    
    
  
  
  xhttp.onreadystatechange = function() {
    if (this.readyState === 4 && this.status === 200) {
        this.responseText = "Succesfully added a user";
    }
  };
    var ar1 = document.getElementById(name).value;
    var ar2 = document.getElementById(surname).value;
  
    xhttp.open("GET", "addUser?name=" + ar1 + "&surname=" + ar2, true);
    xhttp.send();
    window.location.href = "./index.html";
}


function addAdmin(name,surname) {
    var xhttp = new XMLHttpRequest();
  
  xhttp.onreadystatechange = function() {
    if (this.readyState === 4 && this.status === 200) {
        this.responseText = "Succesfully added a user";
    }
  };
    var ar1 = document.getElementById(name).value;
    var ar2 = document.getElementById(surname).value;
  
    xhttp.open("GET", "addAdmin?name=" + ar1 + "&surname=" + ar2, true);
    xhttp.send();
    window.location.href = "./index.html";
}

