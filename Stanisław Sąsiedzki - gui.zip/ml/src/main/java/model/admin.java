/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ssasied
 * admin class inherited from user
 */
public class admin extends user {
    
    public admin(String name, String surname, int id) {
        super(name, surname, id);
    }
    
    
    
    
    
}
