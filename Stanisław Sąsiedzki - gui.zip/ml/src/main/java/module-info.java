module com.library.ml {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;

    opens com.library.ml to javafx.fxml;
    exports com.library.ml;
}
